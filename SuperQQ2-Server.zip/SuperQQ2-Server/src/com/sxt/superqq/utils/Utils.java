package com.sxt.superqq.utils;

import java.util.Arrays;

public class Utils {
	/**
	 * ������ĩβ����һ��Ԫ��
	 * @param list
	 * @param t
	 * @return
	 */
	public static <T> T[] add(T[] list,T t){
		list=Arrays.copyOf(list, list.length+1);
		list[list.length-1]=t;
		return list;
	}
}
