package com.sxt.superqq.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.codehaus.jackson.map.ObjectMapper;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.sxt.superqq.I;
import com.sxt.superqq.SuperQQApplication;
import com.sxt.superqq.bean.ContactBean;
import com.sxt.superqq.bean.UserBean;
import com.sxt.superqq.listener.OnSetAvatarListener;

public final class NetUtil {

	/**
	 * 向app服务器注册
	 * @param user
	 * @return
	 * @throws Exception
	 */
	public static boolean register(UserBean user) throws Exception{
		ArrayList<BasicNameValuePair> params=new ArrayList<BasicNameValuePair>();
		params.add(new BasicNameValuePair(I.KEY_REQUEST, I.REQUEST_REGISTER));
		params.add(new BasicNameValuePair(I.User.USER_NAME, user.getUserName()));
		params.add(new BasicNameValuePair(I.User.NICK, user.getNick()));
		params.add(new BasicNameValuePair(I.User.PASSWORD, user.getPassword()));
		
		 InputStream inputStream = HttpUtils.getInputStream(I.SERVER_ROOT, params, HttpUtils.METHOD_GET);
		 ObjectMapper om=new ObjectMapper();
		 Boolean isSuccess=om.readValue(inputStream, Boolean.class);
		 
		return isSuccess;
	}
	
	/**
	 * 上传头像
	 * @param activity：当前Activity
	 * @param userName：用户账号
	 * @return
	 * @throws IOException 
	 */
	public static boolean uploadAvatar(Activity activity,String userName) throws IOException{
		File file=new File(ImageUtils.getAvatarPath(activity, "user_avatar"), userName+".jpg");
		FileInputStream in=new FileInputStream(file);
		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		DataOutputStream dos=new DataOutputStream(baos);
		
		dos.writeInt(I.REQUEST_UPLOAD_AVATAR.length());
		dos.write(I.REQUEST_UPLOAD_AVATAR.getBytes());
		
		String fileName=userName+".jpg";
		dos.writeInt(fileName.length());
		dos.write(fileName.getBytes());

		int len;
		byte[] buffer=new byte[1024];
		while((len=in.read(buffer))!=-1){
			dos.write(buffer, 0, len);
		}
		ByteArrayInputStream bais=new ByteArrayInputStream(baos.toByteArray());
		InputStreamEntity inputStream=new InputStreamEntity(bais, bais.available());
		
		HttpClient client=new DefaultHttpClient();
		HttpPost post=new HttpPost(I.SERVER_ROOT);
		post.setEntity(inputStream);
		HttpResponse response = client.execute(post);
		if(response.getStatusLine().getStatusCode()!=200){
			return true;
		}
		return false;
	}
	
	/**
	 * 从应用服务器下载头像
	 * @param activity
	 */
	public static void downloadAvatar(Activity activity){
		String userName=SuperQQApplication.getInstance().getUserName();
		File file = OnSetAvatarListener.getAvatarFile(activity,userName);
		if(!file.exists()){
			ArrayList<BasicNameValuePair> params=new ArrayList<BasicNameValuePair>();
			params.add(new BasicNameValuePair(I.KEY_REQUEST, I.REQUEST_DOWNLOAD_AVATAR));
			params.add(new BasicNameValuePair(I.User.USER_NAME, userName));
			try {
				InputStream in = HttpUtils.getInputStream(I.SERVER_ROOT, params, HttpUtils.METHOD_GET);
				Bitmap avatar = BitmapFactory.decodeStream(in);
				OutputStream out=new FileOutputStream(file);
				avatar.compress(CompressFormat.JPEG, 100, out);
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * 登陆应用服务器
	 * @param userName：账号
	 * @param password：密码
	 * @return true:登陆成功
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 * @throws IllegalStateException 
	 */
	public static UserBean login(String userName,String password) throws IllegalStateException, ClientProtocolException, IOException{
		
		ArrayList<BasicNameValuePair> params=new ArrayList<BasicNameValuePair>();
		params.add(new BasicNameValuePair(I.KEY_REQUEST, I.REQUEST_LOGIN));
		params.add(new BasicNameValuePair(I.User.USER_NAME, userName));
		params.add(new BasicNameValuePair(I.User.PASSWORD, password));
		InputStream in = HttpUtils.getInputStream(I.SERVER_ROOT, params, HttpUtils.METHOD_GET);
		ObjectMapper om=new ObjectMapper();
		UserBean user = om.readValue(in, UserBean.class);
		return user;
	}
	
	public static ContactBean addContact(String userName,String name){
		
		ArrayList<BasicNameValuePair> params=new ArrayList<BasicNameValuePair>();
		params.add(new BasicNameValuePair(I.KEY_REQUEST, I.REQUEST_ADD_CONTACT));
		params.add(new BasicNameValuePair(I.User.USER_NAME, userName));
		params.add(new BasicNameValuePair(I.Contact.NAME, name));
		try {
			InputStream in = HttpUtils.getInputStream(I.SERVER_ROOT, params, HttpUtils.METHOD_GET);
			ObjectMapper om=new ObjectMapper();
			ContactBean contact = om.readValue(in, ContactBean.class);
			return contact;
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			HttpUtils.closeClient();
		}
		return null;
	}
	
	/**
	 * 删除联系人
	 * @param myuid:当前用户的id
	 * @param cuid：联系人的id
	 */
	public static void deleteContact(int myuid,int cuid){
		
		ArrayList<BasicNameValuePair> params=new ArrayList<BasicNameValuePair>();
		params.add(new BasicNameValuePair(I.KEY_REQUEST, I.REQUEST_DELETE_CONTACT));
		params.add(new BasicNameValuePair(I.Contact.MYUID, myuid+""));
		params.add(new BasicNameValuePair(I.Contact.CUID, cuid+""));
		try {
			InputStream in = HttpUtils.getInputStream(I.SERVER_ROOT, params, HttpUtils.METHOD_GET);
			ObjectMapper om=new ObjectMapper();
			Boolean isSuccess = om.readValue(in, Boolean.class);
			Log.i("main","删除联系人成功:"+isSuccess);
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			HttpUtils.closeClient();
		}
	}
	
	public static UserBean findUserByUserName(String userName){
		
		ArrayList<BasicNameValuePair> params=new ArrayList<BasicNameValuePair>();
		params.add(new BasicNameValuePair(I.KEY_REQUEST, I.REQUEST_FIND_USER));
		params.add(new BasicNameValuePair(I.User.USER_NAME, userName));
		try {
			InputStream in = HttpUtils.getInputStream(I.SERVER_ROOT, params, HttpUtils.METHOD_GET);
			ObjectMapper om=new ObjectMapper();
			UserBean user = om.readValue(in, UserBean.class);
			return user;
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			HttpUtils.closeClient();
		}
		return null;
	}
	
	/**
	 * 上传当前用户的当前位置信息
	 * @return
	 */
	public static boolean uploadLocation(){
		Boolean isSuccess = false;
		UserBean user = SuperQQApplication.getInstance().getUser();
		
		ArrayList<BasicNameValuePair> params=new ArrayList<BasicNameValuePair>();
		params.add(new BasicNameValuePair(I.KEY_REQUEST, I.REQUEST_UPLOAD_LOCATION));
		params.add(new BasicNameValuePair(I.User.USER_NAME, user.getUserName()));
		params.add(new BasicNameValuePair(I.User.LATITUDE, user.getLatitude()+""));
		params.add(new BasicNameValuePair(I.User.LONGITUDE, user.getLongitude()+""));
		params.add(new BasicNameValuePair(I.User.ID, user.getId()+""));
		try {
			InputStream in = HttpUtils.getInputStream(I.SERVER_ROOT, params, HttpUtils.METHOD_GET);
			
			ObjectMapper om=new ObjectMapper();
			isSuccess = om.readValue(in, Boolean.class);
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			HttpUtils.closeClient();
		}
		return isSuccess;
	}
	
	/**
	 * 下载指定范围的用户数据，目的：获取用户的地理位置信息
	 * @param pageId
	 * @param pageSize
	 * @return
	 */
	public static ArrayList<UserBean> downloadLocation(int pageId,int pageSize){
		ArrayList<UserBean> users=null;
		String userName = SuperQQApplication.getInstance().getUserName();
		
		ArrayList<BasicNameValuePair> params=new ArrayList<BasicNameValuePair>();
		params.add(new BasicNameValuePair(I.KEY_REQUEST, I.REQUEST_DOWNLOAD_LOCATION));
		params.add(new BasicNameValuePair(I.User.USER_NAME, userName));
		params.add(new BasicNameValuePair(I.PAGE_ID, pageId+""));
		params.add(new BasicNameValuePair(I.PAGE_SIZE, pageSize+""));
		try {
			InputStream in = HttpUtils.getInputStream(I.SERVER_ROOT, params, HttpUtils.METHOD_GET);
			ObjectMapper om=new ObjectMapper();
			UserBean[] userArray = om.readValue(in, UserBean[].class);
			List<UserBean> list = Arrays.asList(userArray);
			users=new ArrayList<UserBean>(list);
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			HttpUtils.closeClient();
		}
		return users;
	}
}
