package com.sxt.superqq.activity;

import java.util.ArrayList;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.mapapi.SDKInitializer;
import com.sxt.superqq.R;
import com.sxt.superqq.SuperQQApplication;
import com.sxt.superqq.adapter.NearPeopleAdapter;
import com.sxt.superqq.bean.UserBean;
import com.sxt.superqq.utils.NetUtil;

public class NearPeopleActivity extends BaseActivity {

	/**定位*/
	LocationClient mLocationClient;
	/**当前位置*/
	BDLocation mLastLocation;
	
	MyLocationListener myLocationListener=new MyLocationListener();
	
	ListView mlvNearPeople;
	
	NearPeopleActivity mInstance;
	
	BaiDuSDKReceiver mBaiduReceiver;
	
	NearPeopleAdapter mAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//使用百度sdk组件前初始化，注意必须在setContentView方法之前调用。
		SDKInitializer.initialize(getApplicationContext());
		setContentView(R.layout.activity_near_people);
		mInstance=this;
		//注册百度sdk监听器
		registerBaiduReceiver();
		//位置监听客户端
		mLocationClient=new LocationClient(mInstance);
		//注册位置监听器
		mLocationClient.registerLocationListener(myLocationListener);
	}

	/**
	 * 注册百度sdk监听器
	 */
	private void registerBaiduReceiver() {
		mBaiduReceiver=new BaiDuSDKReceiver();
		IntentFilter filter=new IntentFilter();
		filter.addAction(SDKInitializer.SDK_BROADCAST_ACTION_STRING_NETWORK_ERROR);
		filter.addAction(SDKInitializer.SDK_BROADTCAST_ACTION_STRING_PERMISSION_CHECK_ERROR);
		registerReceiver(mBaiduReceiver, filter);
	}

	/**
	 * 定位监听器，位置更新时，获取最新位置
	 * @author yao
	 *
	 */
	class MyLocationListener implements BDLocationListener{
		@Override
		public void onReceiveLocation(BDLocation location) {
			if(location==null){
				return ;
			}
			if(mLastLocation!=null){
				if(mLastLocation.getLatitude()-location.getLatitude()<0.000001
					&&mLastLocation.getLongitude()-location.getLongitude()<0.000001){
					Log.i("main","位置不变");
					return ;
				}
			}
			mLastLocation=location;
			new UploadLocationTask(location.getLatitude(), location.getLongitude()).execute();
		}

		@Override
		public void onReceivePoi(BDLocation arg0) {
			// TODO Auto-generated method stub
			
		}
	}
	
	/**
	 * 上传当前用户的当前位置信息
	 * @author yao
	 *
	 */
	class UploadLocationTask extends AsyncTask<String, Void, Boolean>{
		double latitude;
		double longitude;
		/**上传当前用户的当前位置信息*/
		public UploadLocationTask(double latitude, double longitude) {
			super();
			this.latitude = latitude;
			this.longitude = longitude;
		}

		@Override
		protected Boolean doInBackground(String... params) {
			UserBean user = SuperQQApplication.getInstance().getUser();
			user.setLatitude(latitude);
			user.setLongitude(longitude);
			boolean isSuccess = NetUtil.uploadLocation();
			if(isSuccess){
				new DownloadLocationTask().execute();
			}
			return isSuccess;
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			if(result){
				new DownloadLocationTask().execute();
			}
		}
	}
	
	/**
	 * 下载除了当前用户之外，所有允许获取位置的用户的信息。
	 * @author yao
	 *
	 */
	class DownloadLocationTask extends AsyncTask<Void, Void, ArrayList<UserBean>>{
		
		@Override
		protected ArrayList<UserBean> doInBackground(Void... params) {
			ArrayList<UserBean> users = NetUtil.downloadLocation(0,20);
			return users;
		}
		
		@SuppressWarnings("unchecked")
		@Override
		protected void onPostExecute(ArrayList<UserBean> result) {
			if(result!=null){
//				for (UserBean user : result) {
//					Log.i("main",user.toString());
//				}
				mlvNearPeople=(ListView) findViewById(R.id.lvNearPeople);
				mAdapter=new NearPeopleAdapter(mInstance, result);
				mlvNearPeople.setAdapter(mAdapter);
			}
		}
	}

	/**
	 * 百度sdk key和网络异常监听器
	 * @author yao
	 *
	 */
	class BaiDuSDKReceiver extends BroadcastReceiver{
		@Override
		public void onReceive(Context context, Intent intent) {
			String networkError = getResources().getString(R.string.Network_error);
			String action=intent.getAction();
			if(action.equals(SDKInitializer.SDK_BROADCAST_ACTION_STRING_NETWORK_ERROR)){
				Toast.makeText(mInstance, networkError, Toast.LENGTH_LONG).show();
			}else if(action.equals(SDKInitializer.SDK_BROADTCAST_ACTION_STRING_PERMISSION_CHECK_ERROR)){
				Toast.makeText(mInstance, getResources().getString(R.string.please_check),Toast.LENGTH_LONG).show();
			}
		}
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if(mLocationClient!=null){
			mLocationClient.stop();
		}
		mLastLocation=null;
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		if(mLocationClient!=null){
			mLocationClient.start();
		}
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		if(mLocationClient!=null){
			mLocationClient.stop();
			mLocationClient=null;
			unregisterReceiver(mBaiduReceiver);
		}
	}
	
}
