package com.sxt.superqq.servlet;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.sxt.superqq.bean.ContactBean;
import com.sxt.superqq.bean.UserBean;
import com.sxt.superqq.biz.ISuperQQBiz;
import com.sxt.superqq.biz.SuperQQBiz;

/**
 * Servlet implementation class Server
 */
@WebServlet("/Server")
public class Server extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ISuperQQBiz biz;

	static final String KEY_REQUEST = "request";
	/**
	 * �ͻ��˷��͵�ע������
	 */
	static final String REQUEST_REGISTER = "register";
	/**
	 * �ͻ����ϴ�ͷ�������
	 */
	static final String REQUEST_UPLOAD_AVATAR = "upload_avatar";
	/**
	 * �ͻ��˷��͵ĵ�½����
	 */
	static final String REQUEST_LOGIN = "login";

	static final String REQUEST_DOWNLOAD_AVATAR = "download_avatar";

	static final String ISON8859_1 = "iso8859-1";
	static final String UTF_8 = "utf-8";

	static final String AVATAR_PATH = "F:/0-Android/project/GeekGarden/superqq/avatar/";

	static final String REQUEST_DOWNLOAD_CONTACTS = "download_contacts";

	static final String REQUEST_DOWNLOAD_CONTACT_LIST = "download_contact_list";

	static final String REQUEST_DELETE_CONTACT = "delete_contact";

	static final String REQUEST_ADD_CONTACT = "add_contact";

	static final String REQUEST_FIND_USER = "find_user";

	static final String REQUEST_DONWLOAD_CONTACTS = "download_contacts";

	static final String REQUEST_UPLOAD_LOCATION = "upload_location";

	static final String REQUEST_DOWNLOAD_LOCATION = "download_location";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Server() {
		super();
		biz = new SuperQQBiz();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String requestType = request.getParameter(KEY_REQUEST);
		if (requestType == null) {
			return;
		}
		switch (requestType) {
		case REQUEST_REGISTER:
			register(request, response);
			break;
		case REQUEST_LOGIN:
			login(response, request);
			break;
		case REQUEST_DOWNLOAD_AVATAR:
			downloadAvatar(request, response);
			break;
		case REQUEST_DOWNLOAD_CONTACTS:
			downloadContacts(request, response);
			break;
		case REQUEST_DOWNLOAD_CONTACT_LIST:
			downloadContact_List(request, response);
			break;
		case REQUEST_ADD_CONTACT:
			addContact(request, response);
			break;
		case REQUEST_DELETE_CONTACT:
			deleteContact(request, response);
			break;
		case REQUEST_FIND_USER:
			findUserByUserName(request, response);
			break;
		case REQUEST_UPLOAD_LOCATION:
			uploadLocation(request, response);
			break;
		case REQUEST_DOWNLOAD_LOCATION:
			downloadLocation(request, response);
			break;
		}
	}

	/**
	 * ���س��˵�ǰ�û�֮�⣬����������ȡλ����Ϣ���û�
	 * 
	 * @param request
	 * @param response
	 */
	private void downloadLocation(HttpServletRequest request,
			HttpServletResponse response) {
		String userName = request.getParameter(ISuperQQBiz.User.USER_NAME);
		int pageId = Integer
				.parseInt(request.getParameter(ISuperQQBiz.PAGE_ID));
		int pageSize = Integer.parseInt(request
				.getParameter(ISuperQQBiz.PAGE_SIZE));
		UserBean[] users = biz.findUsers4Location(userName, pageId, pageSize);

		if (users != null) {
			ObjectMapper om = new ObjectMapper();
			try {
				om.writeValue(response.getOutputStream(), users);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**
	 * ���տͻ����ϴ��ĵ�ǰ�û���λ����Ϣ
	 * 
	 * @param request
	 * @param response
	 */
	private void uploadLocation(HttpServletRequest request,
			HttpServletResponse response) {
		String userName = request.getParameter(ISuperQQBiz.User.USER_NAME);
		int id = Integer.parseInt(request.getParameter(ISuperQQBiz.User.ID));
		double latitude = Double.parseDouble(request
				.getParameter(ISuperQQBiz.User.LATITUDE));
		double longitude = Double.parseDouble(request
				.getParameter(ISuperQQBiz.User.LONGITUDE));

		UserBean user = biz.findUserByUserName(userName);
		user.setLatitude(latitude);
		user.setLongitude(longitude);
		boolean isSuccess = biz.updateUser(user);

		if (isSuccess) { // �޸�����cuid��id��contact���м�¼��Ϣ
			ContactBean contact = new ContactBean();
			contact.setCuid(id);
			// ����myuid�鿴cuid��λ����Ϣ
			contact.setGetMyLocation(true);
			biz.updateContact(contact);
			ObjectMapper om = new ObjectMapper();
			try {
				om.writeValue(response.getOutputStream(), isSuccess);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * ��Ӧ�ͻ��˲�ѯ��ϵ�˵����󣬷���ָ���˺ŵ���ϵ��
	 * 
	 * @param request
	 * @param response
	 */
	private void findUserByUserName(HttpServletRequest request,
			HttpServletResponse response) {
		String userName = request.getParameter(ISuperQQBiz.User.USER_NAME);
		UserBean user = biz.findUserByUserName(userName);
		ObjectMapper om = new ObjectMapper();
		try {
			om.writeValue(response.getOutputStream(), user);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * ��Ӧ�ͻ��˵�����ɾ����ϵ��
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonGenerationException
	 */
	private void deleteContact(HttpServletRequest request,
			HttpServletResponse response) throws JsonGenerationException,
			JsonMappingException, IOException {
		int myuid = Integer.parseInt(request
				.getParameter(ISuperQQBiz.Contact.MYUID));
		int cuid = Integer.parseInt(request
				.getParameter(ISuperQQBiz.Contact.CUID));
		boolean isSuccess = biz.deleteContact(myuid, cuid);
		ObjectMapper om = new ObjectMapper();
		om.writeValue(response.getOutputStream(), isSuccess);
	}

	/**
	 * ��Ӧ�ͻ����ϴ���ϵ�˵�����
	 * 
	 * @param request
	 * @param response
	 */
	private void addContact(HttpServletRequest request,
			HttpServletResponse response) {
		String userName = request.getParameter(ISuperQQBiz.User.USER_NAME);
		String name = request.getParameter(ISuperQQBiz.Contact.NAME);
		ContactBean contact = biz.addContact(userName, name);
		if (contact == null) {
			contact = new ContactBean();
			contact.setResult("failure");
		}
		ObjectMapper om = new ObjectMapper();
		try {
			om.writeValue(response.getOutputStream(), contact);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * ����ArrayLisr<UserBean>
	 * 
	 * @param request
	 * @param response
	 */
	private void downloadContact_List(HttpServletRequest request,
			HttpServletResponse response) {
		String userName = request.getParameter(ISuperQQBiz.User.USER_NAME);
		int pageId = Integer
				.parseInt(request.getParameter(ISuperQQBiz.PAGE_ID));
		int pageSize = Integer.parseInt(request
				.getParameter(ISuperQQBiz.PAGE_SIZE));
		UserBean user = biz.findUserByUserName(userName);
		UserBean[] users = biz.findContactListByMyuid(user.getId(), pageId,
				pageSize);
		ObjectMapper om = new ObjectMapper();
		try {
			om.writeValue(response.getOutputStream(), users);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * ��Ӧ�ͻ���Ҫ������ָ����Ŀ����ϵ��->ContacBean[]
	 * 
	 * @param request
	 * @param response
	 */
	private void downloadContacts(HttpServletRequest request,
			HttpServletResponse response) {
		String userName = request.getParameter(ISuperQQBiz.User.USER_NAME);
		int pageId = Integer
				.parseInt(request.getParameter(ISuperQQBiz.PAGE_ID));
		int pageSize = Integer.parseInt(request
				.getParameter(ISuperQQBiz.PAGE_SIZE));
		ContactBean[] contacts = biz.findContactsByUserName(userName, pageId,
				pageSize);
		if (contacts != null) {
			ObjectMapper om = new ObjectMapper();
			try {
				om.writeValue(response.getOutputStream(), contacts);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * ��Ӧ�û���ͷ������
	 * 
	 * @param request
	 * @param response
	 */
	private void downloadAvatar(HttpServletRequest request,
			HttpServletResponse response) {
		String userName = request.getParameter(ISuperQQBiz.User.USER_NAME);
		File file = new File(AVATAR_PATH + userName + ".jpg");
		if (!file.exists()) {
			System.out.println("���û�ͷ�񲻴���");
			return;
		}
		FileInputStream in = null;
		try {
			in = new FileInputStream(file);
			ServletOutputStream out = response.getOutputStream();
			int len;
			byte[] buffer = new byte[1024];
			while ((len = in.read(buffer)) != -1) {
				out.write(buffer, 0, len);
			}
			System.out.println(userName + "ͷ���������");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * ��Ӧ�û��ĵ�½
	 * 
	 * @param response
	 * @param request
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonGenerationException
	 */
	private void login(HttpServletResponse response, HttpServletRequest request)
			throws JsonGenerationException, JsonMappingException, IOException {
		String userName = request.getParameter(ISuperQQBiz.User.USER_NAME);
		String password = request.getParameter(ISuperQQBiz.User.PASSWORD);
		ObjectMapper om = new ObjectMapper();
		UserBean user = null;
		try {
			user = biz.login(userName, password);
			user.setResult("ok");
			System.out.println("��½�ɹ�");
		} catch (Exception e) {
			user = new UserBean();
			user.setResult("faiure");
			System.out.println("��½ʧ��");
		}
		om.writeValue(response.getOutputStream(), user);
	}

	/**
	 * ��Ӧ�ͻ��˵�ע������
	 * 
	 * @param request
	 * @param response
	 * @throws UnsupportedEncodingException
	 */
	private void register(HttpServletRequest request,
			HttpServletResponse response) throws UnsupportedEncodingException {
		// ����1-��reqeust�л�ȡuserName��nick��password
		String userName = request.getParameter(ISuperQQBiz.User.USER_NAME);
		String nick = request.getParameter(ISuperQQBiz.User.NICK);
		// �����������
		nick = new String(nick.getBytes(ISON8859_1), UTF_8);
		String password = request.getParameter(ISuperQQBiz.User.PASSWORD);
		// ����2-���������ݷ�װ��һ��UserBean������
		UserBean user = new UserBean(userName, nick, password);
		try {
			// ����3-����ҵ���߼���ķ�������ע��
			boolean isSuccess = biz.register(user);
			// ����4����isSuccess���͸��ͻ���
			ObjectMapper om = new ObjectMapper();
			om.writeValue(response.getOutputStream(), isSuccess);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String requestType = request.getParameter(KEY_REQUEST);
		if (requestType == null) {
			uploadData(request, response);
		}

	}

	/**
	 * �ϴ�����
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	private void uploadData(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		ServletInputStream in = request.getInputStream();
		DataInputStream dis = new DataInputStream(in);
		int requestLen = dis.readInt();
		byte[] buffer = new byte[1024];
		int len = dis.read(buffer, 0, requestLen);
		String requestType = new String(buffer, 0, len);
		switch (requestType) {
		case REQUEST_UPLOAD_AVATAR:
			uploadAvatar(dis, response);
			break;
		default:
			break;
		}
	}

	/**
	 * �ϴ�ͷ��
	 * 
	 * @param dis
	 * @param response
	 * @throws IOException
	 */
	private void uploadAvatar(DataInputStream dis, HttpServletResponse response)
			throws IOException {
		int userNameLen = dis.readInt();
		byte[] buffer = new byte[1024 * 8];
		int len = dis.read(buffer, 0, userNameLen);
		String fileName = new String(buffer, 0, len);

		File file = new File(AVATAR_PATH, fileName);
		FileOutputStream fos = new FileOutputStream(file);
		while ((len = dis.read(buffer)) != -1) {
			fos.write(buffer, 0, len);
		}
		String userName = fileName.replace(".jpg", "");
		UserBean user = biz.findUserByUserName(userName);
		user.setAvatar(AVATAR_PATH + fileName);
		biz.updateUser(user);
		System.out.println("ͷ���ϴ��ɹ���·��:" + AVATAR_PATH + fileName);
		fos.close();
	}

}
