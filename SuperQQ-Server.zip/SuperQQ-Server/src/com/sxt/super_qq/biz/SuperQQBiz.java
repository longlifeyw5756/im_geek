package com.sxt.super_qq.biz;

import com.sxt.super_qq.bean.ContactBean;
import com.sxt.super_qq.bean.UserBean;
import com.sxt.super_qq.dao.ISuperQQDao;
import com.sxt.super_qq.dao.SuperQQDao;
/**
 * ҵ���߼����ʵ����
 * @author yao
 *
 */
public class SuperQQBiz implements ISuperQQBiz {
	ISuperQQDao dao;//�������ݷ��ʲ�����ñ���
	private ContactBean[] findContactsByUserName;
	
	/**
	 * ҵ���߼���Ĺ�����
	 */
	public SuperQQBiz() {
		dao=new SuperQQDao();
	}
	
	@Override
	public boolean register(UserBean user) throws Exception {
		if(dao.findUserByUserName(user.getUserName())!=null){
			throw new Exception("���û��Ѵ���");
		}
		boolean isSuccess = dao.addUser(user);
		return isSuccess;
	}

	@Override
	public UserBean login(String userName, String password) throws Exception {
		UserBean user = dao.findUserByUserName(userName);
		if(user==null){
			throw new Exception("����ע��");
		}
		if(!user.getPassword().equals(password)){
			throw new Exception("�������");
		}
		return user;
	}

	@Override
	public UserBean findUserByUserName(String userName) {
		return dao.findUserByUserName(userName);
	}

	@Override
	public UserBean[] findUsersByUserName(String userName, int pageId,
			int pageSize) {
		UserBean[] users = findUsersByUserName(userName, pageId, pageSize);
		return users;
	}

	@Override
	public UserBean[] findUsersByNick(String nick, int pageId, int pageSize) {
		UserBean[] users = dao.findUsersByNick(nick, pageId, pageSize);
		return users;
	}

	@Override
	public UserBean[] findUsers4Location(String userName,int pageId,int pageSize) {
		UserBean[] users = dao.findUsers4Location(userName, pageId, pageSize);
		return users;
	}

	@Override
	public boolean updateUser(UserBean user) {
		boolean isSuccess = dao.updateUser(user);
		return isSuccess;
	}

	@Override
	public ContactBean findContactById(int myuid, int cuid) {
		ContactBean contact = dao.findContactById(myuid, cuid);
		return contact;
	}

	@Override
	public ContactBean[] findContactsByUserName(String userName, int pageId,
			int pageSize) {
		ContactBean[] contacts = dao.findContactsByUserName(userName, pageId, pageSize);
		return contacts;
	}

	@Override
	public UserBean[] findContactListByMyuid(int myuid, int pageId, int pageSize) {
		UserBean[] users = dao.findContactsByMyuid(myuid, pageId, pageSize);
		return users;
	}

	@Override
	public ContactBean addContact(String userName, String name) {
		ContactBean contact = dao.addContact(userName, name);
		return contact;
	}

	@Override
	public boolean deleteContact(int myuid, int cuid) {
		boolean isSuccess = dao.deleteContact(myuid, cuid);
		return isSuccess;
	}

	@Override
	public boolean updateContact(ContactBean contact) {
		boolean isSuccess = dao.updateContact(contact);
		return isSuccess;
	}

}
