package com.sxt.super_qq.servlet;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.sxt.super_qq.bean.ContactBean;
import com.sxt.super_qq.bean.UserBean;
import com.sxt.super_qq.biz.ISuperQQBiz;
import com.sxt.super_qq.biz.SuperQQBiz;

/** ������Ӧ�ֻ��ͻ��˵�����
 * Servlet implementation class Server
 */
@WebServlet("/Server")
public class Server extends HttpServlet {
	private static final long serialVersionUID = 1L;
    ISuperQQBiz biz;
    
    static final String KEY_REQUEST="request";
    /**
     * �ͻ��˷��͵�ע������
     */
    static final String REQUEST_REGISTER="register";
    /**
     * �ͻ����ϴ�ͷ�������
     */
    static final String REQUEST_UPLOAD_AVATAR="upload_avatar";
    /**
     * �ͻ��˷��͵ĵ�½����
     */
    static final String REQUEST_LOGIN="login";
    
    /**
     * �ͻ�������ͷ�������
     */
    static final String REQUEST_DOWNLOAD_AVATAR="download_avatar";
    
    static final String REQUEST_DOWNLOAD_CONTACTS="download_contacts";

    static final String REQUEST_DOWNLOAD_CONTACTLIST="download_contactlist";
    
    /** ������ϵ�˵�����*/
    static final String REQUEST_ADD_CONTACT="add_contact";
    
    /** �����û���Ϣ*/
    static final String REQUEST_FIND_USER="find_user";
    
    static final String ISON8859_1="iso8859-1";
    static final String UTF_8="utf-8";
    
    static final String AVATAR_PATH="F:/0-Android/project/GeekGarden/superqq/avatar/";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Server() {
        super();
        biz=new SuperQQBiz();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String requestType=request.getParameter(KEY_REQUEST);
		if(requestType==null){
			return ;
		}
		switch (requestType) {
		case REQUEST_REGISTER:
			register(request,response);
			break;
		case REQUEST_LOGIN:
			login(request,response);
			break;
		case REQUEST_DOWNLOAD_AVATAR:
			downloadAvatar(request,response);
			break;
		case REQUEST_DOWNLOAD_CONTACTS:
			downloadConacts(request,response);
			break;
		case REQUEST_DOWNLOAD_CONTACTLIST:
			downloadContactList(request,response);
			break;
		case REQUEST_ADD_CONTACT:
			addContact(request,response);
			break;
		case REQUEST_FIND_USER:
			findUser(request,response);
			break;
		}
	}

	/**
	 * ��Ӧ�ͻ��˵���������ָ���˺ŵ�UserBean����
	 * @param request
	 * @param response
	 */
	private void findUser(HttpServletRequest request,
			HttpServletResponse response) {
		String userName=request.getParameter(ISuperQQBiz.User.USER_NAME);
		UserBean user = biz.findUserByUserName(userName);
		user.setResult("ok");
		
		ObjectMapper om=new ObjectMapper();
		try {
			om.writeValue(response.getOutputStream(), user);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * ��Ӧ�ͻ���������ϵ�˵�����
	 * �����ݿ��contact������һ����¼��������ContactBean����
	 * ����͸��ͻ���.
	 * @param request
	 * @param response
	 */
	private void addContact(HttpServletRequest request,
			HttpServletResponse response) {
		String userName=request.getParameter(ISuperQQBiz.User.USER_NAME);
		String name=request.getParameter(ISuperQQBiz.Contact.NAME);
		ContactBean contact = biz.addContact(userName, name);
		if(contact==null){
			contact=new ContactBean();
			contact.setResult("failure");
		}
		//��contac�����͸��ͻ���
		ObjectMapper om=new ObjectMapper();
		try {
			om.writeValue(response.getOutputStream(), contact);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * ��Ӧ�ͻ��˵���������ΪArrayList<UserBean>������
	 * @param request
	 * @param response
	 */
	private void downloadContactList(HttpServletRequest request,
			HttpServletResponse response) {
		String userName=request.getParameter(ISuperQQBiz.User.USER_NAME);
		int pageId=Integer.parseInt(request.getParameter(ISuperQQBiz.PAGE_ID));
		int pageSize=Integer.parseInt(request.getParameter(ISuperQQBiz.PAGE_SIZE));
		UserBean user=biz.findUserByUserName(userName);
		UserBean[] users = biz.findContactListByMyuid(user.getId(), pageId, pageSize);
		
		ObjectMapper om=new ObjectMapper();
		try {
			om.writeValue(response.getOutputStream(), users);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * ��Ӧ�ͻ�����������ΪContactBean����ϵ������
	 * @param request
	 * @param response
	 */
	private void downloadConacts(HttpServletRequest request,
			HttpServletResponse response) {
		//ȡ���ͻ����ϴ����������
		String userName=request.getParameter(ISuperQQBiz.User.USER_NAME);
		int pageId=Integer.parseInt(request.getParameter(ISuperQQBiz.PAGE_ID));
		int pageSize=Integer.parseInt(request.getParameter(ISuperQQBiz.PAGE_SIZE));
		//����ҵ���߼������userName��ȡһ��ContactBean����
		ContactBean[] contacts = biz.findContactsByUserName(userName, pageId, pageSize);
		//���͸��ͻ���
		ObjectMapper om=new ObjectMapper();
		try {
			om.writeValue(response.getOutputStream(), contacts);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * ��Ӧ�ͻ�������ͷ�������
	 * @param request
	 * @param response
	 * @throws IOException 
	 */
	private void downloadAvatar(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String userName=request.getParameter(ISuperQQBiz.User.USER_NAME);
		FileInputStream fis=null;
		try {
			File file=new File(AVATAR_PATH+userName+".jpg");
			if(!file.exists()){
				System.out.println("û��"+userName+"��ͷ��");
				return ;
			}
			fis=new FileInputStream(file);
			ServletOutputStream out = response.getOutputStream();
			int len;
			byte[] buffer=new byte[1024*5];
			while((len=fis.read(buffer))!=-1){
				out.write(buffer, 0, len);
			}
			System.out.println(userName+"��ͷ���������");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(fis!=null){
				fis.close();
			}
		}
	}

	/**
	 * ��Ӧ�ͻ��˵ĵ�½����
	 * @param request
	 * @param response
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonGenerationException 
	 */
	private void login(HttpServletRequest request, HttpServletResponse response) throws JsonGenerationException, JsonMappingException, IOException {
		String userName=request.getParameter(ISuperQQBiz.User.USER_NAME);
		String password=request.getParameter(ISuperQQBiz.User.PASSWORD);
		UserBean user = null;
		try {
			user = biz.login(userName, password);
			user.setResult("ok");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			user=new UserBean();
			user.setResult(e.getMessage());
		}
		//��ͻ��˷���UserBean����
		ObjectMapper om=new ObjectMapper();
		om.writeValue(response.getOutputStream(), user);
	}

	/**
	 * ��Ӧ�ͻ��˵�ע������
	 * @param request
	 * @param response
	 * @throws UnsupportedEncodingException 
	 */
	private void register(HttpServletRequest request,
			HttpServletResponse response) throws UnsupportedEncodingException {
		//����1-��reqeust�л�ȡuserName��nick��password
		String userName=request.getParameter(ISuperQQBiz.User.USER_NAME);
		String nick=request.getParameter(ISuperQQBiz.User.NICK);
		//�����������
		nick=new String(nick.getBytes(ISON8859_1),UTF_8);
		String password=request.getParameter(ISuperQQBiz.User.PASSWORD);
		//����2-���������ݷ�װ��һ��UserBean������
		UserBean user=new UserBean(userName, nick, password);
		try {
			//����3-����ҵ���߼���ķ�������ע��
			boolean isSuccess = biz.register(user);
			//����4����isSuccess���͸��ͻ���
			ObjectMapper om=new ObjectMapper();
			om.writeValue(response.getOutputStream(), isSuccess);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//��ȡ�ͻ����ϴ�����������
		String requestType = request.getParameter(KEY_REQUEST);
		if(requestType==null){
			uploadData(request,response);
		}
	}

	/**
	 * ������տͻ����ϴ��Ĵ����ݵ�����
	 * @param request
	 * @param repponse
	 * @throws IOException 
	 */
	private void uploadData(HttpServletRequest request, HttpServletResponse reponse) throws IOException {
		DataInputStream dis=new DataInputStream(request.getInputStream());
		int reqeustLength=dis.readInt();
		byte[] buffer=new byte[100];
		int len=dis.read(buffer, 0, reqeustLength);
		String requestType=new String(buffer,0,len);
		switch (requestType) {
		case REQUEST_UPLOAD_AVATAR:
			uploadAvatar(dis,reponse);
			break;
		default:
			break;
		}
	}

	/**
	 * �����ͻ����ϴ�ͷ��
	 * @param dis:��װ��ͷ������������
	 * @param repponse
	 * @throws IOException 
	 */
	private void uploadAvatar(DataInputStream dis, HttpServletResponse response)  {
		ObjectMapper om=new ObjectMapper();
		FileOutputStream fos=null;
		try {
			int userNameLen = dis.readInt();
			byte[] buffer=new byte[1024*5];
			int len=dis.read(buffer, 0, userNameLen);
			String userName=new String(buffer, 0, len);
			String path=AVATAR_PATH+userName+".jpg";
			fos=new FileOutputStream(path);
			while((len=dis.read(buffer))!=-1){
				fos.write(buffer, 0, len);
			}
			System.out.println("�ϴ�ͷ��ɹ�");
			om.writeValue(response.getOutputStream(), true);
			UserBean user=biz.findUserByUserName(userName);
			user.setAvatar(path);//�޸�ͷ��ı���·��
			biz.updateUser(user);
		} catch (Exception e) {
			try {
				om.writeValue(response.getOutputStream(), false);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally{
			if(fos!=null){
				try {
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}


}
