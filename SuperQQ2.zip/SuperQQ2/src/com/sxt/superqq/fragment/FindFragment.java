package com.sxt.superqq.fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import com.sxt.superqq.R;
import com.sxt.superqq.activity.NearPeopleActivity;
/**
 * 发现的Fragment
 * @author yao
 *
 */
public class FindFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
    	View layout=inflater.inflate(R.layout.fragment_find, container, false);
    	setListener(layout);
        return layout;
    }


	private void setListener(View layout) {
		layout.findViewById(R.id.tvNearPeople).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());
				CharSequence hint=getActivity().getResources().getString(R.string.near_hint);
				builder.setTitle("提示")
					.setMessage(hint)
					.setPositiveButton("确定", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							getActivity().startActivity(new Intent(getActivity(), NearPeopleActivity.class));
						}
					})
					.setNegativeButton("取消", null)
					.create().show();
			}
		});
	}

}
