/**
 * Copyright (C) 2013-2014 EaseMob Technologies. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sxt.superqq.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.easemob.EMError;
import com.easemob.chat.EMChatManager;
import com.easemob.exceptions.EaseMobException;
import com.sxt.superqq.SuperQQApplication;
import com.sxt.superqq.I;
import com.sxt.superqq.R;
import com.sxt.superqq.bean.UserBean;
import com.sxt.superqq.listener.OnSetAvatarListener;
import com.sxt.superqq.utils.ImageUtils;
import com.sxt.superqq.utils.NetUtil;

/**
 * 注册页
 * 
 */
public class RegisterActivity extends BaseActivity {
	private EditText metUserName;
	private EditText metPassword;
	private EditText metConfirmPassword;
	private EditText metNick;
	private ImageView mivAvatar;
	
	RegisterActivity mContext;
	
	OnSetAvatarListener mOnSetAvatarListener;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext=this;
		setContentView(R.layout.activity_register);
		initView();
		setListener();
	}

	/**
	 * 设置注册按钮单击事件监听
	 */
	private void setListener() {
		setRegisterClickListener();
		setSetAvatarClickListener();
	}

	/**
	 * 设置头像的单击事件监听
	 */
	private void setSetAvatarClickListener() {
		mOnSetAvatarListener=new OnSetAvatarListener(this, R.id.layout_register);
		findViewById(R.id.iv_avatar).setOnClickListener(mOnSetAvatarListener);
	}

	private void setRegisterClickListener() {
		findViewById(R.id.btnRegister).setOnClickListener(new OnClickListener() {
			String userName;
			String nick;
			String password;
			@Override
			public void onClick(View v) {
				userName = metUserName.getText().toString().trim();
				password = metPassword.getText().toString().trim();
				String confirm_pwd = metConfirmPassword.getText().toString().trim();
				if (TextUtils.isEmpty(userName)) {
					metUserName.requestFocus();
					metUserName.setError(getResources().getString(R.string.User_name_cannot_be_empty));
					return;
				}
				nick=metNick.getText().toString();
				if(TextUtils.isEmpty(nick)){
					metNick.setError("昵称不能为空");
					metNick.requestFocus();
					return ;
				}
				if (TextUtils.isEmpty(password)) {
					metPassword.setText(getResources().getString(R.string.Password_cannot_be_empty));
					metPassword.requestFocus();
					return;
				}
				if (TextUtils.isEmpty(confirm_pwd)) {
					metConfirmPassword.requestFocus();
					metConfirmPassword.setText(getResources().getString(R.string.Two_input_password));
					return;
				}
				if (!password.equals(confirm_pwd)) {
					Toast.makeText(mContext, "密码不一致", Toast.LENGTH_SHORT).show();
					return;
				}

				if (!TextUtils.isEmpty(userName) && !TextUtils.isEmpty(password)) {
					//将输入的账号、昵称和密码封装一个实体类中
					UserBean user=new UserBean(userName, nick, password);
					//启动异步任务，向环信服务器和应用服务器注册
					new RegisterTask(RegisterActivity.this, user).execute(I.SERVER_ROOT);

				}
			}
		});
	}

	/**
	 * 初始化view
	 */
	private void initView() {
		metUserName = (EditText) findViewById(R.id.username);
		metPassword = (EditText) findViewById(R.id.password);
		metConfirmPassword = (EditText) findViewById(R.id.confirm_password);
		metNick=(EditText) findViewById(R.id.et_nick);
		mivAvatar=(ImageView) findViewById(R.id.iv_avatar);
	}

	public void back(View view) {
		finish();
	}

	/**
	 * 用于注册的异步任务类
	 * @author yao
	 *
	 */
	class RegisterTask extends AsyncTask<String, Void, String>{
		Activity activity;
		UserBean user;
		ProgressDialog dialog;
		
		@Override
		protected void onPreExecute() {
			dialog=new ProgressDialog(activity);
			dialog.setMessage("注册中...");
			dialog.show();
		}
		public RegisterTask(Activity activity, UserBean user) {
			super();
			this.activity = activity;
			this.user = user;
		}

		@Override
		protected String doInBackground(String... params) {
			String result=null;
			try {
				// 调用sdk注册方法
				EMChatManager.getInstance().createAccountOnServer(user.getUserName(), user.getPassword());
				
				boolean isSuccess=NetUtil.register(user);
				if(isSuccess){
					// 保存用户名
					SuperQQApplication.getInstance().setUserName(user.getUserName());
					isSuccess = NetUtil.uploadAvatar(mContext, user.getUserName());
					if(isSuccess){
						result= "注册成功";
					}else{
						result="注册成功,但头像上传失败";
					}
				}else{
					result="注册失败";
				}
			} catch (final EaseMobException e) {
				int errorCode=e.getErrorCode();
				if(errorCode==EMError.NONETWORK_ERROR){
				}else if(errorCode==EMError.USER_ALREADY_EXISTS){
					result=getResources().getString(R.string.User_already_exists);
				}else if(errorCode==EMError.UNAUTHORIZED){
					result=getResources().getString(R.string.registration_failed_without_permission);
				}else{
					result=getResources().getString(R.string.Registration_failed);
				}
			} catch (Exception e) {
				result="注册失败";
			}
			return result;
		}
		
		@Override
		protected void onPostExecute(String result) {
			dialog.dismiss();
			Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
			if(result.indexOf("注册成功")>=0){
				finish();
			}
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode!=RESULT_OK){
			return ;
		}
		String userName=null;
		switch (requestCode) {
		case OnSetAvatarListener.REQUEST_CHOOSE_PHOTO:
			mOnSetAvatarListener.startCropPhoto(data.getData(), 200, 200, 
				OnSetAvatarListener.REQUEST_PHOTO_CROP, true);
			break;
		case OnSetAvatarListener.REQUEST_TAKE_PHOTO:
			userName=getUserName();
			if(userName!=null){
				Uri uri = Uri.fromFile(mOnSetAvatarListener.getAvatarFile(this,userName));
				mOnSetAvatarListener.startCropPhoto(uri, 200, 200, OnSetAvatarListener.REQUEST_PHOTO_CROP, true);
			}
			break;
		case OnSetAvatarListener.REQUEST_PHOTO_CROP:
			mOnSetAvatarListener.closePopAvatar();
			if(data==null){
				return ;
			}
			userName=getUserName();
			if(userName!=null){
				mOnSetAvatarListener.saveCropPhoto(mivAvatar, data,userName);
			}
			break;
		}
	}
	
	 public String getUserName(){
        String userName=metUserName.getText().toString();
        if(TextUtils.isEmpty(userName)){
            metUserName.setError("请先输入账号");
            metUserName.requestFocus();
            return null;
        }
        return userName;
    }
	 
}
