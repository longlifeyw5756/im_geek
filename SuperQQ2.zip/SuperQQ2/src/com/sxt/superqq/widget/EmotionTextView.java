package com.sxt.superqq.widget;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.widget.TextView;

public class EmotionTextView extends TextView {

	public EmotionTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setText(CharSequence text, BufferType type) {
		if(TextUtils.isEmpty(text)){
			super.setText(text, type);
		}else{
			super.setText(replace(text.toString()),type);
		}
	}

	/**
	 * 将表示表情图片的文字替换为图片
	 * @param text
	 * @return
	 */
	private CharSequence replace(String text) {
		Matcher matcher=Pattern.compile("ee_[\\d]{1,2}").matcher(text);
		int start=0;
		SpannableString ss=new SpannableString(text);
		while(matcher.find()){
			String key = matcher.group();
			int id = getResources().getIdentifier(key, "drawable", getContext().getPackageName());
			Bitmap bitmap = BitmapFactory.decodeResource(getResources(), id);
			ImageSpan span=new ImageSpan(bitmap);
			int startIndex=text.indexOf(key, start);
			if(startIndex>=0){
				ss.setSpan(span, startIndex, startIndex+key.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
				start=startIndex+key.length()-1;
			}
		}
		return ss;
	}
}
