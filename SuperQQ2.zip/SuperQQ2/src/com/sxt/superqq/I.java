package com.sxt.superqq;

public interface I {
	
	public static final String SERVER_ROOT="http://10.0.2.2:8080/SuperQQ2-Server/Server";
	
	public static final String PAGE_ID="page_id";
	public static final String PAGE_SIZE="page_size";
	
	public static class User{
		public static final String ID="id";
		public static final String UID="uid";
		public static final String USER_NAME="userName";
		
		public static final String NICK="nick";
		public static final String AVATAR="avatar";
		public static final String HEADER="header";
		public static final String PASSWORD="password";
		public static final String LATITUDE="latitude";
		public static final String LONGITUDE="longitude";
		public static final String UN_READ_MSG_COUNT="unreadMsgCount";
		
	}
	
	public static class Contact extends User{
		public static final String NAME="name";
		public static final String MYUID="myuid";
		public static final String CUID="cuid";
		public static final String IS_GET_MY_LOCATION="isGetMyLocation";
		public static final String IS_SHOW_MY_LOCATION="isShowMyLocation";
	}
	
	/** 请求的键*/
	String KEY_REQUEST="request";
    /**
     * 客户端发送的注册请求
     */
	String REQUEST_REGISTER="register";
    
    String REQUEST_UPLOAD_AVATAR="upload_avatar";

    String REQUEST_LOGIN="login";
    
    String REQUEST_DOWNLOAD_AVATAR="download_avatar";
    
    /** 下载头像的接口*/
    String DOWNLOAD_AVATAR_URL=SERVER_ROOT+
        "?request="+REQUEST_DOWNLOAD_AVATAR+"&userName=&avatar=";
    
    String REQUEST_DOWNLOAD_CONTACTS="download_contacts";
    
    String REQUEST_DOWNLOAD_CONTACT_LIST="download_contact_list";
    
    String REQUEST_DELETE_CONTACT="delete_contact";
    
    String REQUEST_ADD_CONTACT="add_contact";
    
    String REQUEST_FIND_USER="find_user";
    
    String REQUEST_UPLOAD_LOCATION="upload_location";
    
    String REQUEST_DOWNLOAD_LOCATION="download_location";
    
}
