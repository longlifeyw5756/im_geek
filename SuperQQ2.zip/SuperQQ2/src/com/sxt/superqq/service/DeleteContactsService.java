package com.sxt.superqq.service;

import java.util.ArrayList;

import android.app.IntentService;
import android.content.Intent;

import com.sxt.superqq.bean.ContactBean;
import com.sxt.superqq.utils.NetUtil;

public class DeleteContactsService extends IntentService {

	public DeleteContactsService() {
		super("DeleteContactsService");
	}

	@Override
	protected void onHandleIntent(Intent intent) {
		ArrayList<ContactBean> contacts= (ArrayList<ContactBean>) intent.getSerializableExtra("delete_contacts");
		for (ContactBean contact : contacts) {//删除服务端的联系人
			NetUtil.deleteContact(contact.getMyuid(), contact.getCuid());
		}
	}

}
