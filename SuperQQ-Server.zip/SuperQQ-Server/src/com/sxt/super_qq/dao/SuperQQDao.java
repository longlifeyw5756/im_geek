package com.sxt.super_qq.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Scanner;

import com.sxt.super_qq.bean.ContactBean;
import com.sxt.super_qq.bean.UserBean;
import com.sxt.super_qq.biz.ISuperQQBiz;
import com.sxt.super_qq.utils.JdbcUtils;
/**
 * ���ݷ��ʲ��ʵ����
 * @author yao
 *
 */
public class SuperQQDao implements ISuperQQDao {

	@Override
	public UserBean findUserByUserName(String userName) {
		//��Ų�ѯ���
		ResultSet set=null;
		//���Ԥ�����sql����
		PreparedStatement statement=null;
		//�������ݿ�
		Connection connection = JdbcUtils.getConnection();
		//�����ѯ��sql���
		String sql="select * from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.USER_NAME+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, userName);
			set=statement.executeQuery();
			if(set.next()){//ָ����һ����¼�������ǵ�һ����¼
				UserBean user=readUser(set);
				return user;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		return null;
	}

	/**
	 * ��set�ж�ȡһ����¼������UserBean���͵�ʵ��
	 * @param set:��ѯ�Ľ����
	 * @return
	 * @throws SQLException 
	 */
	private UserBean readUser(ResultSet set) throws SQLException {
		UserBean user=new UserBean();
		int id=set.getInt(1);
		user.setId(id);
		
		String userName=set.getString(ISuperQQBiz.User.USER_NAME);
		user.setUserName(userName);
		
		String nick=set.getString(ISuperQQBiz.User.NICK);
		user.setNick(nick);
		
		String avatar=set.getString(ISuperQQBiz.User.AVATAR);
		user.setAvatar(avatar);
		
		String password=set.getString(ISuperQQBiz.User.PASSWORD);
		user.setPassword(password);
		
		double latitude=set.getDouble(ISuperQQBiz.User.LATITUDE);
		user.setLatitude(latitude);
		
		double longitude=set.getDouble(ISuperQQBiz.User.LONGITUDE);
		user.setLongitude(longitude);
		
		int unreadMsgCount=set.getInt(ISuperQQBiz.User.UN_READ_MSG_COUNT);
		user.setUnreadMsgCount(unreadMsgCount);
				
		return user;
	}

	@Override
	public UserBean[] findUsersByUserName(String userName, int pageId,
			int pageSize) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.USER_NAME+" like ? limit ?,?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, "%"+userName+"%");
			statement.setInt(2, pageId);
			statement.setInt(3, pageSize);
			set=statement.executeQuery();
			UserBean[] users=new UserBean[0];
			while(set.next()){
				UserBean user = readUser(set);
				if(user!=null){
					users=add(users, user);
				}
			}
			return users;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		return null;
	}

	@Override
	public UserBean[] findUsersByNick(String nick, int pageId, int pageSize) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.NICK+" like ?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, "%"+nick+"%");
			set=statement.executeQuery();
			UserBean[] users=new UserBean[0];
			while(set.next()){
				UserBean user = readUser(set);
				users=add(users,user);
			}
			return users;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		return null;
	}

	@Override
	public UserBean[] findUsers4Location(String userName, int pageId,
			int pageSize) {
		/**
		 * ���������н��в�ѯ
		 * 
		 */
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.USER_NAME+"<>? and "
			+ISuperQQBiz.User.ID+" in(select "
			+ISuperQQBiz.Contact.CUID
			+" from "+ISuperQQBiz.Contact.TABLE_NAME
			+" where "+ISuperQQBiz.Contact.IS_GET_MY_LOCATION+"=1)";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, userName);
			set=statement.executeQuery();
			UserBean[] users=new UserBean[0];
			while(set.next()){
				UserBean user = readUser(set);
				users=add(users, user);
			}
			return users;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		return null;
	}

	@Override
	public boolean addUser(UserBean user) {
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="insert into "+ISuperQQBiz.User.TABLE_NAME
			+"("+ISuperQQBiz.User.USER_NAME
			+","+ISuperQQBiz.User.NICK
			+","+ISuperQQBiz.User.PASSWORD
			+","+ISuperQQBiz.User.LATITUDE
			+","+ISuperQQBiz.User.LONGITUDE
			+","+ISuperQQBiz.User.UN_READ_MSG_COUNT
			+")values(?,?,?,?,?,?)";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, user.getUserName());
			statement.setString(2, user.getNick());
			statement.setString(3, user.getPassword());
			statement.setDouble(4, 0);
			statement.setDouble(5, 0);
			statement.setInt(6, 0);
			int count = statement.executeUpdate();
			return count==1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(null, statement, connection);
		}
		return false;
	}

	@Override
	public boolean updateUser(UserBean user) {
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="update "+ISuperQQBiz.User.TABLE_NAME
			+" set "+ISuperQQBiz.User.NICK+"=?,"
			+ISuperQQBiz.User.AVATAR+"=?,"
			+ISuperQQBiz.User.LATITUDE+"=?,"
			+ISuperQQBiz.User.LONGITUDE+"=?"
			+" where "+ISuperQQBiz.User.USER_NAME+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, user.getNick());
			statement.setString(2, user.getAvatar());
			statement.setDouble(3, 0);
			statement.setDouble(4, 0);
			statement.setString(5, user.getUserName());
			int count = statement.executeUpdate();
			return count==1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(null, statement, connection);
		}
		return false;
	}

	@Override
	public boolean isExistsContact(String userName, String name) {
		//����1����user���в�ѯuserNameֵ��userName��id
		int myuid=findIdByUserName(userName);
		//����2����user���в�ѯuseNameֵ��name��id
		int cuid=findIdByUserName(name);
		//��ѯcontact����myuid����ѯ������user����userName
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select "+ISuperQQBiz.Contact.MYUID
			+" from "+ISuperQQBiz.Contact.TABLE_NAME
			+" where "+ISuperQQBiz.Contact.MYUID+"=? and "
			+ISuperQQBiz.Contact.CUID+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setInt(1, myuid);
			statement.setInt(2, cuid);
			set=statement.executeQuery();
			if(set.next()){
				return set.getInt(1)>0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	/**
	 * ����userName��ֵ��ѯid
	 * @param userName
	 * @return
	 */
	private int findIdByUserName(String userName) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select "+ISuperQQBiz.User.ID
			+" from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.USER_NAME+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, userName);
			set=statement.executeQuery();
			if(set.next()){
				int id=set.getInt(1);
				return id;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		return 0;
	}

	@Override
	public ContactBean findContactById(int myuid, int cuid) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.Contact.TABLE_NAME
			+" where "+ISuperQQBiz.Contact.MYUID+"=? and "
			+ISuperQQBiz.Contact.CUID+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setInt(1, myuid);
			statement.setInt(2, cuid);
			set=statement.executeQuery();
			if(set.next()){
				ContactBean contact=readContact(set);
				return contact;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		return null;
	}

	@Override
	public ContactBean[] findContactsByUserName(String userName, int pageId,
			int pageSize) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.Contact.TABLE_NAME
			+" where "+ISuperQQBiz.Contact.MYUID+"=(select "
			+ISuperQQBiz.User.ID
			+" from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.USER_NAME+"=?)";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, userName);
			set=statement.executeQuery();
			ContactBean[] contacts=new ContactBean[0];
			while(set.next()){
				ContactBean contact=readContact(set);
				contacts=add(contacts,contact);
			}
			return contacts;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		
		return null;
	}

	/**
	 * ��set������contact���ж�ȡһ����¼
	 * @param set
	 * @return
	 * @throws SQLException 
	 */
	private ContactBean readContact(ResultSet set) throws SQLException {
		int myuid=set.getInt(ISuperQQBiz.Contact.MYUID);
		int cuid=set.getInt(ISuperQQBiz.Contact.CUID);
		boolean isGetMyLocation=set.getBoolean(ISuperQQBiz.Contact.IS_GET_MY_LOCATION);
		boolean isShowMyLocatin=set.getBoolean(ISuperQQBiz.Contact.IS_SHOW_MY_LOCATION);
		ContactBean contact=new ContactBean(myuid, cuid, isGetMyLocation, isShowMyLocatin);
		
		return contact;
	}

	@Override
	public UserBean[] findContactsByMyuid(int myuid, int pageId, int pageSize) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.ID+" in("
			+"select "+ISuperQQBiz.Contact.CUID+" from "
			+ISuperQQBiz.Contact.TABLE_NAME
			+" where "+ISuperQQBiz.Contact.MYUID+"=?)"
			+" limit ?,?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setInt(1, myuid);
			statement.setInt(2, pageId);
			statement.setInt(3, pageSize);
			set=statement.executeQuery();
			UserBean[] users=new UserBean[0];
			while(set.next()){
				UserBean user=readUser(set);
				users=add(users, user);
			}
			return users;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		return null;
	}

	@Override
	public ContactBean addContact(String userName, String name) {
		boolean existsContact = isExistsContact(userName, name);
		if(existsContact){
			System.out.println("�Ѿ�����ϵ��");
			return null;
		}
		int myuid=findIdByUserName(userName);
		int cuid=findIdByUserName(name);
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="insert into "+ISuperQQBiz.Contact.TABLE_NAME
			+"("+ISuperQQBiz.Contact.MYUID
			+","+ISuperQQBiz.Contact.CUID
			+")values(?,?)";
		try {
			statement=connection.prepareStatement(sql);
			statement.setInt(1, myuid);
			statement.setInt(2, cuid);
			int count = statement.executeUpdate();
			ContactBean contact = findContactById(myuid, cuid);
			contact.setResult("ok");
			return contact;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(null, statement, connection);
		}
		return null;
	}

	@Override
	public boolean deleteContact(int myuid, int cuid) {
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="delete from "+ISuperQQBiz.Contact.TABLE_NAME
			+" where "+ISuperQQBiz.Contact.MYUID+"=? and "
			+ISuperQQBiz.Contact.CUID+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setInt(1, myuid);
			statement.setInt(2, cuid);
			int count = statement.executeUpdate();
			return count==1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(null, statement, connection);
		}
		return false;
	}

	@Override
	public boolean updateContact(ContactBean contact) {
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="update "+ISuperQQBiz.Contact.TABLE_NAME
			+" set "+ISuperQQBiz.Contact.IS_GET_MY_LOCATION+"=?"
			+","+ISuperQQBiz.Contact.IS_SHOW_MY_LOCATION+"=?"
			+" where "+ISuperQQBiz.Contact.MYUID+"=? and "
			+ISuperQQBiz.Contact.CUID+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setBoolean(1, contact.isGetMyLocation());
			statement.setBoolean(2, contact.isShowMyLocation());
			statement.setInt(3, contact.getMyuid());
			statement.setInt(4, contact.getCuid());
			int count = statement.executeUpdate();
			return count==1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(null, statement, connection);
		}
		
		return false;
	}

	/**
	 * ��t���ӵ�����array֮��
	 * @param array
	 * @param t
	 * @return
	 */
	private <T> T[] add(T[] array,T t){
		//��������
		array=Arrays.copyOf(array, array.length+1);
		//��user����users�����һ��Ԫ��
		array[array.length-1]=t;
		return array;
	}
	public static void main(String[] args) {
		SuperQQDao dao=new SuperQQDao();
		UserBean user=null;
		UserBean[] users=null;
		ContactBean[] contacts = null;
		System.out.println("1-����findUserByUserName()");
		System.out.println("2-����findUsersByUserName()");
		System.out.println("3-����findUsersByNick()");
		System.out.println("4-����findUsers4Location()");
		System.out.println("5-����isExistsContact()");
		System.out.println("6-����findContactsByUserName()");
		
		System.out.println("ѡ��1-6");
		int select=new Scanner(System.in).nextInt();
		switch (select) {
		case 1:
			user=dao.findUserByUserName("a");
			System.out.println(user);
			break;
		case 2:
			users = dao.findUsersByUserName("a", 0, 20);
			if(users!=null){
				for (UserBean u : users) {
					System.out.println(u);
				}
			}
			break;
		case 3:
			users=dao.findUsersByNick("a", 0, 20);
			if(users!=null){
				for (UserBean u : users) {
					System.out.println(u);
				}
			}
			break;
		case 4:
			users=dao.findUsers4Location("a", 0, 20);
			if(users!=null){
				for (UserBean u : users) {
					System.out.println(u);
				}
			}
			break;
		case 5:
			boolean existsContact = dao.isExistsContact("aa", "aaa");
			System.out.println("aa ��aaa����ϵ�ˣ�"+existsContact);
			break;
		case 6:
			contacts = dao.findContactsByUserName("a", 0, 20);
			if(contacts!=null){
				for (ContactBean contact : contacts) {
					System.out.println(contact);
				}
			}
			break;
		}
	}
}
