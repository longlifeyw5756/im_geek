package com.sxt.superqq.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.catalina.startup.Tomcat.ExistingStandardWrapper;

import com.sxt.superqq.bean.ContactBean;
import com.sxt.superqq.bean.UserBean;
import com.sxt.superqq.biz.ISuperQQBiz;
import com.sxt.superqq.utils.JdbcUtils;
import com.sxt.superqq.utils.Utils;

/**
 * ���ݷ��ʲ�
 * @author yao
 *
 */
public class SuperQQDao implements ISuperQQDao {

	@Override
	public UserBean findUserByUserName(String userName) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.USER_NAME+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, userName);
			set=statement.executeQuery();
			if(set.next()){
				UserBean user=readUser(set);
				return user;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		return null;
	}

	/**
	 * ��set�ж�ȡuser����һ����¼
	 * @param set
	 * @return
	 * @throws SQLException 
	 */
	private UserBean readUser(ResultSet set) throws SQLException {
		int id=set.getInt(ISuperQQBiz.User.ID);
		String userName=set.getString(ISuperQQBiz.User.USER_NAME);
		String nick=set.getString(ISuperQQBiz.User.NICK);
		String avatar=set.getString(ISuperQQBiz.User.AVATAR);
		String password=set.getString(ISuperQQBiz.User.PASSWORD);
		double latitude=set.getDouble(ISuperQQBiz.User.LATITUDE);
		double longitude=set.getDouble(ISuperQQBiz.User.LONGITUDE);
		int unreadMsgCount=set.getInt(ISuperQQBiz.User.UN_READ_MSG_COUNT);
		String result="ok";
		UserBean user=new UserBean(id, result, userName, nick, password, avatar, latitude, longitude, unreadMsgCount);
		return user;
	}

	@Override
	public UserBean[] findUsersByUserName(String userName, int pageId,
			int pageSize) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.USER_NAME+" like ?"
			+" limit ?,?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, "%"+userName+"%");
			statement.setInt(2, pageId);
			statement.setInt(3, pageSize);
			set=statement.executeQuery();
			UserBean[] users=new UserBean[0];
			while(set.next()){
				UserBean user=readUser(set);
				users=Utils.add(users,user);
			}
			return users;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public UserBean[] findUsersByNick(String nick, int pageId, int pageSize) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.NICK+" like ?"
			+" limit ?,?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, "%"+nick+"%");
			statement.setInt(2, pageId);
			statement.setInt(3, pageSize);
			set=statement.executeQuery();
			UserBean[] users=new UserBean[0];
			while(set.next()){
				UserBean user=readUser(set);
				users=Utils.add(users,user);
			}
			return users;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public UserBean[] findUsers4Location(String userName,int pageId,int pageSize) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.USER_NAME+" <>? "
			+" and "+ISuperQQBiz.User.ID+" in(select "
			+ISuperQQBiz.Contact.MYUID+" from "
			+ISuperQQBiz.Contact.TABLE_NAME
			+" where "+ISuperQQBiz.Contact.IS_GET_MY_LOCATION+"=1"
			+")limit ?,?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, userName);
			statement.setInt(2, pageId);
			statement.setInt(3, pageSize);
			set=statement.executeQuery();
			UserBean[] users=new UserBean[0];
			while(set.next()){
				UserBean user=readUser(set);
				users=Utils.add(users,user);
			}
			return users;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean addUser(UserBean user) {
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="insert into "+ISuperQQBiz.User.TABLE_NAME
			+"("+ISuperQQBiz.User.USER_NAME
			+","+ISuperQQBiz.User.NICK
			+","+ISuperQQBiz.User.PASSWORD
			+","+ISuperQQBiz.User.LATITUDE
			+","+ISuperQQBiz.User.LONGITUDE
			+","+ISuperQQBiz.User.UN_READ_MSG_COUNT
			+")values(?,?,?,?,?,?)";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, user.getUserName());
			statement.setString(2, user.getNick());
			statement.setString(3, user.getPassword());
			statement.setDouble(4, 0);
			statement.setDouble(5, 0);
			statement.setInt(6, 0);
			int count = statement.executeUpdate();
			return count==1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(null, statement, connection);
		}
			
		return false;
	}

	@Override
	public boolean updateUser(UserBean user) {
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="update "+ISuperQQBiz.User.TABLE_NAME
			+" set "+ISuperQQBiz.User.NICK+"=?,"
			+ISuperQQBiz.User.AVATAR+"=?,"
			+ISuperQQBiz.User.LATITUDE+"=?,"
			+ISuperQQBiz.User.LONGITUDE+"=?"
			+" where "+ISuperQQBiz.User.USER_NAME+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, user.getNick());
			statement.setString(2, user.getAvatar());
			statement.setDouble(3, user.getLatitude());
			statement.setDouble(4, user.getLongitude());
			statement.setString(5, user.getUserName());
			int count = statement.executeUpdate();
			return count==1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(null, statement, connection);
		}
		return false;
	}

	@Override
	public boolean isExistsContact(String userName, String name) {
		int myuid=findIdByUserName(userName);
		int cuid=findIdByUserName(name);
		PreparedStatement statement=null;
		ResultSet set=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select "+ISuperQQBiz.Contact.ID
			+" from "+ISuperQQBiz.Contact.TABLE_NAME
			+" where "+ISuperQQBiz.Contact.MYUID+"=?"
			+" and "+ISuperQQBiz.Contact.CUID+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setInt(1, myuid);
			statement.setInt(2, cuid);
			set=statement.executeQuery();
			if(set.next()){
				int id=set.getInt(ISuperQQBiz.Contact.ID);
				return id>0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		return false;
	}

	/**
	 * �����˺Ų�ѯid
	 * @param userName
	 * @return
	 */
	private int findIdByUserName(String userName) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select "+ISuperQQBiz.User.ID
			+" from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.USER_NAME+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1,userName);
			set=statement.executeQuery();
			if(set.next()){
				int id=set.getInt(ISuperQQBiz.User.ID);
				return id;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		return 0;
	}

	@Override
	public ContactBean findContactById(int myuid, int cuid) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.Contact.TABLE_NAME
			+" where "+ISuperQQBiz.Contact.MYUID+"=? and "
			+ISuperQQBiz.Contact.CUID+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setInt(1, myuid);
			statement.setInt(2, cuid);
			set=statement.executeQuery();
			if(set.next()){
				ContactBean contact=readContact(set);
				return contact;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		return null;
	}

	/**
	 * ��set�л�ȡcontact���е�һ����¼
	 * @param set
	 * @return
	 * @throws SQLException 
	 */
	private ContactBean readContact(ResultSet set) throws SQLException {
		int myuid=set.getInt(ISuperQQBiz.Contact.MYUID);
		int cuid=set.getInt(ISuperQQBiz.Contact.CUID);
		boolean isGetMyLocation=set.getBoolean(ISuperQQBiz.Contact.IS_GET_MY_LOCATION);
		boolean isShowMyLocation=set.getBoolean(ISuperQQBiz.Contact.IS_SHOW_MY_LOCATION);
		String result="ok";
		ContactBean contact=new ContactBean(result, myuid, cuid, isGetMyLocation, isShowMyLocation);
		return contact;
	}

	@Override
	public ContactBean[] findContactsByUserName(String userName, int pageId,
			int pageSize) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.Contact.TABLE_NAME
			+" where "+ISuperQQBiz.Contact.MYUID+" in("
			+"select "+ISuperQQBiz.User.ID
			+" from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.USER_NAME+"=?)"
			+" limit ?,?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setString(1, userName);
			statement.setInt(2, pageId);
			statement.setInt(3, pageSize);
			set=statement.executeQuery();
			ContactBean[] contacts=new ContactBean[0];
			while(set.next()){
				contacts=Utils.add(contacts, readContact(set));
			}
			return contacts;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		return null;
	}

	@Override
	public UserBean[] findContactListByMyuid(int myuid, int pageId, int pageSize) {
		ResultSet set=null;
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="select * from "+ISuperQQBiz.User.TABLE_NAME
			+" where "+ISuperQQBiz.User.ID+" in("
			+"select "+ISuperQQBiz.Contact.CUID+" from "
			+ISuperQQBiz.Contact.TABLE_NAME
			+" where "+ISuperQQBiz.Contact.MYUID+"=?)"
			+" limit ?,?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setInt(1, myuid);
			statement.setInt(2, pageId);
			statement.setInt(3, pageSize);
			set=statement.executeQuery();
			UserBean[] users=new UserBean[0];
			while(set.next()){
				UserBean user=readUser(set);
				users=Utils.add(users, user);
			}
			return users;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(set, statement, connection);
		}
		
		return null;
	}

	@Override
	public ContactBean addContact(String userName, String name) {
		boolean existsContact = isExistsContact(userName, name);
		if(existsContact){
			System.out.println("�Ѿ�����ϵ��");
			return null;
		}
		int myuid=findIdByUserName(userName);
		int cuid=findIdByUserName(name);
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="insert into "+ISuperQQBiz.Contact.TABLE_NAME
			+"("+ISuperQQBiz.Contact.MYUID
			+","+ISuperQQBiz.Contact.CUID
			+")values(?,?)";
		try {
			statement=connection.prepareStatement(sql);
			statement.setInt(1, myuid);
			statement.setInt(2, cuid);
			int count = statement.executeUpdate();
			ContactBean contact = findContactById(myuid, cuid);
			contact.setResult("ok");
			return contact;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(null, statement, connection);
		}
		return null;
	}

	@Override
	public boolean deleteContact(int myuid, int cuid) {
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="delete from "+ISuperQQBiz.Contact.TABLE_NAME
			+" where "+ISuperQQBiz.Contact.MYUID+"=? and "
			+ISuperQQBiz.Contact.CUID+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setInt(1, myuid);
			statement.setInt(2, cuid);
			int count = statement.executeUpdate();
			return count==1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(null, statement, connection);
		}
		return false;
	}

	@Override
	public boolean updateContact(ContactBean contact) {
		PreparedStatement statement=null;
		Connection connection = JdbcUtils.getConnection();
		String sql="update "+ISuperQQBiz.Contact.TABLE_NAME
			+" set "+ISuperQQBiz.Contact.IS_GET_MY_LOCATION+"=?"
			+","+ISuperQQBiz.Contact.IS_SHOW_MY_LOCATION+"=?"
			+" where "+ISuperQQBiz.Contact.CUID+"=?";
		try {
			statement=connection.prepareStatement(sql);
			statement.setBoolean(1, contact.isGetMyLocation());
			statement.setBoolean(2, contact.isShowMyLocation());
			statement.setInt(3, contact.getCuid());
			int count = statement.executeUpdate();
			return count==1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.closeAll(null, statement, connection);
		}
		
		return false;
	}
	
	/**
	 * ��ӡUserBean����
	 * @param users
	 */
	private static void printUsers(UserBean[] users){
		if(users!=null){
			for (UserBean u : users) {
				System.out.println(u.toString());
			}
		}
	}
	
	public static void main(String[] args) {
		UserBean user=null;
		UserBean[] users=null;
		ContactBean contact=null;
		ContactBean[] contacts=null;
		SuperQQDao dao=new SuperQQDao();
		System.out.println("1-����findUserByUserName()");
		System.out.println("2-����findUsersByUserName()");
		System.out.println("3-����findUsersByNick()");
		System.out.println("4-����findUsers4Location()");
		System.out.println("5-����addUser()");
		System.out.println("6-����updateUser()");
		System.out.println("7-����isExistsContact()");
		System.out.println("8-����findContactByMyuid()");
		System.out.println("9-����findContactsByUserName()");
		System.out.println("10-����findContactListByMyuid()");
		System.out.println("11-����addContact()");
		System.out.println("12-����deleteContact()");
		System.out.println("13-����updateContact()");
		System.out.println("select(1-13)");
		int select=new java.util.Scanner(System.in).nextInt();
		switch (select) {
		case 1:
			user=dao.findUserByUserName("a");
			System.out.println(user.toString());
			break;
		case 2:
			users=dao.findUsersByUserName("a", 0, 20);
			printUsers(users);
		case 3:
			users=dao.findUsersByNick("aa", 0, 20);
			printUsers(users);
			break;
		case 4:
			users=dao.findUsers4Location("a", 0, 20);
			printUsers(users);
			break;
		case 5:
			user=new UserBean("aaaaaa", "aaaaaa", "a");
			boolean isSuccess = dao.addUser(user);
			System.out.println("ע���û��ɹ���"+isSuccess);
			break;
		case 6:
			user=new UserBean("a", "�ŷ�", "a");
			user.setAvatar("F:/0-Android/project/GeekGarden/supertqq/avatar/a.jpg");
			user.setLatitude(40.3957);
			user.setLongitude(116.785);
			boolean isSuccess2 = dao.updateUser(user);
			System.out.println("�޸�user�ɹ���"+isSuccess2);
			break;
		case 7:
			isSuccess = dao.isExistsContact("a", "aaa");
			System.out.println("a��aaa����ϵ�ˣ�"+isSuccess);
			break;
		case 8:
			contact=dao.findContactById(1,2);
			if(contact!=null){
				System.out.println(contact.toString());
			}
			break;
		case 9:
			contacts=dao.findContactsByUserName("a", 0, 20);
			if(contacts!=null){
				for (ContactBean c : contacts) {
					System.out.println(c);
				}
			}
			break;
		case 10:
			users=dao.findContactListByMyuid(1,0,20);
			if(users!=null){
				for (UserBean u : users) {
					System.out.println(u);
				}
			}
			break;
		case 11:
			contact = dao.addContact("aa", "aaa");
			System.out.println("������ϵ�˼�¼�ɹ���"+(contact!=null));
			break;
		case 12:
			boolean deleteContact = dao.deleteContact(2, 3);
			if(deleteContact){
				System.out.println("ɾ����ϵ�˳ɹ�");
			}
			break;
		case 13:
			contact=new ContactBean("ok", 2, 1, true, true);
			isSuccess=dao.updateContact(contact);
			System.out.println("�޸���ϵ�˳ɹ���"+isSuccess);
			break;
		}
		
	}

}
