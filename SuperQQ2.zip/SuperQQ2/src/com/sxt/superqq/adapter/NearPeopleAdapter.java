package com.sxt.superqq.adapter;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.utils.DistanceUtil;
import com.sxt.superqq.I;
import com.sxt.superqq.R;
import com.sxt.superqq.SuperQQApplication;
import com.sxt.superqq.bean.UserBean;
import com.sxt.superqq.utils.ImageLoader;
import com.sxt.superqq.utils.ImageLoader.OnImageLoadListener;
/**
 * 显示附近人的适配器
 * @author yao
 *
 */
public class NearPeopleAdapter extends BaseAdapter {
	Activity activity;
	List<NearUserBean> nearUsers;
	ImageLoader mImageLoader;
	
	public NearPeopleAdapter(Activity activity, List<UserBean> userList) {
		super();
		this.activity = activity;
		nearUsers=new ArrayList<NearPeopleAdapter.NearUserBean>();
		UserBean myUser = SuperQQApplication.getInstance().getUser();
		for (UserBean user : userList) {
			NearUserBean nearUser=new NearUserBean();
			nearUser.user=user;
			LatLng myLatLng=new LatLng(myUser.getLatitude(), myUser.getLongitude());
			LatLng contactLatLng=new LatLng(user.getLatitude(), user.getLongitude());
			nearUser.distance=(int) DistanceUtil.getDistance(myLatLng, contactLatLng);
			nearUsers.add(nearUser);
		}
		mImageLoader=ImageLoader.getInstance(activity);
	}

	@Override
	public int getCount() {

		return nearUsers.size();
	}

	@Override
	public NearUserBean getItem(int position) {
		return nearUsers.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, final ViewGroup parent) {
		ViewHolder holder=null;
		if(convertView==null){
			convertView=View.inflate(activity, R.layout.item_near_people, null);
			holder=new ViewHolder();
			holder.ivAvatar=(ImageView) convertView.findViewById(R.id.ivAvatar);
			holder.tvDistance=(TextView) convertView.findViewById(R.id.tvDistance);
			holder.tvNick=(TextView) convertView.findViewById(R.id.tvNick);
			convertView.setTag(holder);
		}else{
			holder=(ViewHolder) convertView.getTag();
		}
		NearUserBean user = getItem(position);
		holder.tvDistance.setText(user.distance+"");
		holder.tvNick.setText(user.user.getNick());
		
		String path=I.DOWNLOAD_AVATAR_URL.replace("&userName=", "&userName="
			+user.user.getUserName())+user.user.getAvatar();
		Bitmap bitmap = mImageLoader.displayImage(path, 80, 80, new OnImageLoadListener() {
			@Override
			public void onSuccess(String path, Bitmap bitmap) {
				ImageView iv=(ImageView) parent.findViewWithTag(path);
				if(null!=iv){
					iv.setImageBitmap(bitmap);
				}
			}
			
			@Override
			public void error(String errorMsg) {
				// TODO Auto-generated method stub
				
			}
		});
		if(bitmap==null){
			holder.ivAvatar.setImageResource(R.drawable.default_avatar);
		}else{
			holder.ivAvatar.setImageBitmap(bitmap);
		}
		return convertView;
	}

	class ViewHolder{
		ImageView ivAvatar;
		TextView tvNick;
		TextView tvDistance;
	}
	class NearUserBean{
		UserBean user;
		int distance;
	}
}
