package com.sxt.superqq.task;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;
import org.codehaus.jackson.map.ObjectMapper;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;

import com.sxt.superqq.I;
import com.sxt.superqq.SuperQQApplication;
import com.sxt.superqq.bean.ContactBean;
import com.sxt.superqq.bean.UserBean;
import com.sxt.superqq.utils.HttpUtils;

/**
 * 下载账号是userName的联系人集合的异步任务类 
 * 结果保存在SuperQQApplication
 * ArrayList<UserBean>和HashMap<Integer,Contact>
 * 
 * @author yao
 */
public class DownloadContactsTask extends AsyncTask<String, Void, Boolean> {
	Context mContext;
	String mUserName;
	int mPageId;
	int mPageSize;

	/**
	 * 下载账号是userName的联系人集合的异步任务类 结果保存在SuperQQApplication
	 * 
	 * @param userName
	 *            :指定用户的账号
	 * @param pageId
	 *            :页号
	 * @param pageSize
	 *            ：每页下载的记录数
	 */
	public DownloadContactsTask(Context context,String userName, int pageId, int pageSize) {
		super();
		mContext=context;
		this.mUserName = userName;
		this.mPageId = pageId;
		this.mPageSize = pageSize;
	}

	@Override
	protected Boolean doInBackground(String... params) {
		String url = params[0];
		boolean isSuccess = downloadContacts(url);
		if (isSuccess) {
			isSuccess = downloadContactList(url);
		}
		return isSuccess;
	}

	@Override
	protected void onPostExecute(Boolean result) {
		if (result) { // 若联系人下载成功，则
			// 发送更新联系人的广播，ContactListFragment类中的广播接收者接收该广播
			Intent intent = new Intent("update_contacts");
			mContext.sendStickyBroadcast(intent);
		}
	}

	/**
	 * 下载联系人->HashMap<Integer,ContactBean>
	 * 
	 * @param url
	 */
	private boolean downloadContacts(String url) {

		ArrayList<BasicNameValuePair> params = new ArrayList<BasicNameValuePair>();
		params.add(new BasicNameValuePair(I.KEY_REQUEST,
				I.REQUEST_DOWNLOAD_CONTACTS));
		params.add(new BasicNameValuePair(I.User.USER_NAME, mUserName));
		params.add(new BasicNameValuePair(I.PAGE_ID, mPageId + ""));
		params.add(new BasicNameValuePair(I.PAGE_SIZE, mPageSize + ""));
		try {
			InputStream in = HttpUtils.getInputStream(url, params,
				HttpUtils.METHOD_GET);
			ObjectMapper om = new ObjectMapper();
			ContactBean[] contacts = om.readValue(in, ContactBean[].class);
			HashMap<Integer, ContactBean> map = new HashMap<Integer, ContactBean>();
			for (ContactBean contact : contacts) {
				map.put(contact.getCuid(), contact);
			}
			HashMap<Integer, ContactBean> contactMap = SuperQQApplication
					.getInstance().getContacts();
			contactMap.putAll(map);
			// 将下载的联系人集合保存在内存中
			SuperQQApplication.getInstance().setContacts(contactMap);
			return true;
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			HttpUtils.closeClient();
		}
		return false;
	}

	/**
	 * 下载联系人集合：ArrayList<UserBean>
	 * @param url
	 */
	private boolean downloadContactList(String url) {

		ArrayList<BasicNameValuePair> params = new ArrayList<BasicNameValuePair>();
		params.add(new BasicNameValuePair(I.KEY_REQUEST,
				I.REQUEST_DOWNLOAD_CONTACT_LIST));
		params.add(new BasicNameValuePair(I.User.USER_NAME, mUserName));
		params.add(new BasicNameValuePair(I.PAGE_ID, mPageId + ""));
		params.add(new BasicNameValuePair(I.PAGE_SIZE, mPageSize + ""));
		try {
			InputStream in = HttpUtils.getInputStream(url, params,
					HttpUtils.METHOD_GET);
			ObjectMapper om = new ObjectMapper();
			UserBean[] userArray = om.readValue(in, UserBean[].class);
			if(userArray==null){
				return false;
			}
			//将数组转换为集合
			List<UserBean> userList = Arrays.asList(userArray);
			//获取已添加的所有联系人的集合
			ArrayList<UserBean> contactList = SuperQQApplication.getInstance()
					.getContactList();
			//将新下载的数据添加到原联系人集合中
			contactList.addAll(userList);
			SuperQQApplication.getInstance().setContactList(contactList);
			return true;
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			HttpUtils.closeClient();
		}
		return false;
	}

}
